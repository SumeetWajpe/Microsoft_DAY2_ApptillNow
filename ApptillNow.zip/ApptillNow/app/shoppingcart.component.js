"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ShoppingCartComponent = (function () {
    function ShoppingCartComponent() {
        this.productOne = { name: 'Laptop', price: 50000, quantity: 100, rating: 4, ImageUrl: 'https://rukminim1.flixcart.com/image/704/704/j431rbk0/computer/t/h/p/hp-notebook-original-imaev2zfjqfpf3ng.jpeg?q=70' };
        this.productTwo = { name: 'LED TV', price: 25000, quantity: 10, rating: 3.5674, ImageUrl: 'http://www.lg.com/in/images/tvs/md05602497/gallery/Large-940x620.jpg' };
        this.productThree = { name: 'Desktop', price: 10000, quantity: 200, rating: 3, ImageUrl: 'https://images-eu.ssl-images-amazon.com/images/I/41IjXCFmiRL._SL500_AC_SS350_.jpg' };
        this.productFour = { name: 'Mobile', price: 20000, quantity: 1000, rating: 5, ImageUrl: 'https://assets.mspcdn.net/t_c-desktop-normal,f_auto,q_auto,d_c:noimage.jpg/c/8808-62-4.jpg' };
        this.productFive = { name: 'Camera', price: 90000, quantity: 10, rating: 4, ImageUrl: 'https://cdn-4.nikon-cdn.com/e/Q5NM96RZZo-YRYNeYvAi9beHK4x3L-8joW7yUnybX4TANUFk0STA8w==/Views/1554_D7200_left.png' };
    }
    return ShoppingCartComponent;
}());
ShoppingCartComponent = __decorate([
    core_1.Component({
        selector: "cart",
        template: "<h1> Shopping Cart </h1>\n    \n                    <product [details]=\"productOne\"></product>\n                    <product [details]=\"productTwo\"></product>\n                    <product [details]=\"productThree\"></product>\n                    <product [details]=\"productFour\"></product>\n                    <product [details]=\"productFive\"></product>\n                 \n    \n    "
    })
], ShoppingCartComponent);
exports.ShoppingCartComponent = ShoppingCartComponent;
//# sourceMappingURL=shoppingcart.component.js.map