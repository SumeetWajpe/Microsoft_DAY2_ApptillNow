import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template:`<cart>
  
                  </cart>
  `
//   template: `
  
//   <h1>Learning {{name}}</h1>
  
//   <img src="{{url}}" height="200px" width="200px" />
//   <img [src]="url" height="200px" width="200px" />
//   <input type="button" class="btn" [class.btn-success]="isSuccess" value="Styled !" />
// <input type="text" [style.backgroundColor]="isSuccess ? 'green' : 'red'" />


//   `,
})
export class AppComponent  { 
  name:string = 'Angular'; 
  url:string = 'http://rathankalluri.com/wp-content/uploads/2017/04/Angular-js.jpg'
isSuccess:boolean=false;
}
