
import {Component,Input} from '@angular/core';

@Component({
    selector:`product`,
    template:`<h2> {{details.name | uppercase }}  </h2>
                    <img [src]="details.ImageUrl" height="200px" width="200px" /><br/>
                    Price: <b>{{details.price | currency:'INR':true}}</b> <br/>
                    Quantity: <b>{{details.quantity}}</b> <br/>
                    Rating: <b>{{details.rating | number:'1.1-2' }}</b> <br/> 
                    Stock Lasts : <b>{{details.stockLasts | stockduration:'month' }}</b> <br/>                     
                    Raw Data : {{details | json }}                  
                    
                    
                    <hr/>
    `
})
export class ProductComponent{

//   @Input()  name:string = 'Mobile';
@Input()  details:any = {name:'Mobile',price:10000};


}