
import {Component,Input} from '@angular/core';

@Component({
    selector:`product`,
    template:`<h2> {{details.name}}  </h2>
                    <img [src]="details.ImageUrl" height="200px" width="200px" /><br/>
                    Price: <b>{{details.price}}</b> <br/>
                    Quantity: <b>{{details.quantity}}</b> <br/>
                    Rating: <b>{{details.rating}}</b> <br/>
                    
                    
                    
                    <hr/>
    `
})
export class ProductComponent{

//   @Input()  name:string = 'Mobile';
@Input()  details:any = {name:'Mobile',price:10000};


}