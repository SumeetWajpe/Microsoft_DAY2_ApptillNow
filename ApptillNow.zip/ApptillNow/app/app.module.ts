import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';
import { ShoppingCartComponent } from './shoppingcart.component';
import { ProductComponent } from './product.component';



@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent,ShoppingCartComponent,ProductComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
