import {Pipe,PipeTransform} from '@angular/core'

@Pipe({name:'stockduration'})
export class StockDurationPipe implements  PipeTransform{
transform(inputvalue:number,args:string){
        return inputvalue + " " + args;
}
}